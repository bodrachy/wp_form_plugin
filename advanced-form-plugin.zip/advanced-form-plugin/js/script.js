jQuery(document).ready(function ($) {
    $('#advanced-form').submit(function (event) {
        event.preventDefault();

        // Gather form data
        var formData = $(this).serialize();

        // Perform AJAX submission
        $.ajax({
            type: 'POST',
            url: ajaxurl, // WordPress AJAX handler URL
            data: {
                action: 'process_advanced_form',
                form_data: formData,
            },
            success: function (response) {
                // Handle success response
                console.log(response);
            },
            error: function (error) {
                // Handle error
                console.error(error);
            }
        });
    });
});

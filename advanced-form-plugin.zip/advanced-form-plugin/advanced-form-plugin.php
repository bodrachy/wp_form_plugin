<?php
/*
Plugin Name: BOD | Advanced Form Plugin
Description: An advanced form plugin for collecting user data.
Version: 1.0
Author:<a href="bodtech.org.ng">Ayanleke Tola Tosin</a>
*/


class Advanced_Form_Plugin {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts_styles'));
    }

   public function add_admin_menu() {
        add_menu_page(
            'Advanced Form Plugin',
            'BOD | Form Plugin',
            'manage_options',
            'advanced-form-plugin',
            array($this, 'display_form_page')
        );
    }


   
    

    public function enqueue_scripts_styles() {
        wp_enqueue_style('form-plugin-style', plugins_url('css/style.css', __FILE__));
        wp_enqueue_script('form-plugin-script', plugins_url('js/script.js', __FILE__), array('jquery'), '1.0', true);
    }


    public function display_form_page() {
        global $wpdb;
    
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_form'])) {
            $name    = sanitize_text_field($_POST['name']);
            $email   = sanitize_email($_POST['email']);
            $message = sanitize_textarea_field($_POST['message']);
    
            // Insert form data into the database
            $wpdb->insert(
                $wpdb->prefix . 'e_form_submissions', // wp_ is the prefix and table name = wp_e_form_submissions
                array(
                    'name'    => $name,
                    'email'   => $email,
                    'message' => $message,
                    'date'    => current_time('mysql'),
                )
            );
    
            // Display a success message
            echo '<div id="success-message" class="notice notice-success is-dismissible">';
            echo '<p>Form submitted successfully!</p>';
            echo '</div>';
        }
        ?>


        <div class="wrap">
            <h1>BOD Advanced Form Plugin</h1>
            <form method="post" action="">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br><br>
    
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br><br>
    
                <label for="message">Message:</label>
                <textarea rows = "5" cols ="50" id="message" name="message" required></textarea> <br><br>
    
                <input type="submit" name="submit_form" class="button button-primary" value="Submit">
            </form>
        </div>

        <script>
        // success message after 5 seconds
        setTimeout(function() {
            document.getElementById('success-message').style.display = 'none';
        }, 5000); // Adjust the time (in milliseconds)
    </script>


        <?php
    }
    
    /*register_activation_hook(__FILE__, 'advanced_form_plugin_activate');

    function advanced_form_plugin_activate() {
        global $wpdb;
    
        $table_name = $wpdb->prefix . 'form_submissions';
    
        $charset_collate = $wpdb->get_charset_collate();
    
        $sql = "CREATE TABLE wp_form_submissions (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            message text NOT NULL,
            date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
    
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }
    
    or run the below code through sql
    sql code
    CREATE TABLE wp_form_submissions (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            message text NOT NULL,
            date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;
    
    
    */
    
     
    }


$advanced_form_plugin = new Advanced_Form_Plugin();
